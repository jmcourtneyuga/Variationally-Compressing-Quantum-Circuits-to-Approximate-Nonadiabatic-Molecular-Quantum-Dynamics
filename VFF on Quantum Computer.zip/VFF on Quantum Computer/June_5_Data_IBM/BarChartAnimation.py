import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib import rcParams
import pandas as pd

def create_animated_bar_chart(data_file, output_file='animated_bars.mp4', error_file=None):
    """
    Create an animated bar chart from tab-separated data file.
    
    Parameters:
    - data_file: path to tab-separated .txt file with data
    - output_file: output .mp4 filename
    - error_file: optional path to tab-separated .txt file with error bar data
    """
    
    # Set up matplotlib parameters for high quality output
    rcParams['font.family'] = 'Arial'
    rcParams['font.size'] = 64
    rcParams['figure.dpi'] = 100
    
    # Read the data file
    try:
        data = pd.read_csv(data_file, sep='\t', index_col=0)
        print(f"Data loaded successfully from {data_file}")
        print(f"Data shape: {data.shape}")
        print(f"Basis states: {list(data.index)}")
        print(f"Time points: {list(data.columns)}")
    except Exception as e:
        print(f"Error reading data file: {e}")
        return
    
    # Read error data if provided
    errors = None
    if error_file:
        try:
            errors = pd.read_csv(error_file, sep='\t', index_col=0)
            print(f"Error data loaded successfully from {error_file}")
            # Ensure error data has same structure as main data
            if errors.shape != data.shape:
                print("Warning: Error data shape doesn't match main data shape")
                errors = None
        except Exception as e:
            print(f"Error reading error file: {e}")
            errors = None
    
    # Extract basis states and time points
    basis_states = data.index.tolist()
    time_points = data.columns.tolist()
    
    # Set up the figure with 1920x1080 resolution
    fig, ax = plt.subplots(figsize=(19.2, 10.8), dpi=100)
    
    # Calculate bar positions and width
    x_pos = np.arange(len(basis_states))
    bar_width = 0.6  # Thick bars but not touching
    
    # Initialize bars
    bars = ax.bar(x_pos, data.iloc[:, 0], width=bar_width, 
                  color='blue', alpha=0.8, edgecolor='darkgreen', linewidth=1)
    
    # Set up axes
    ax.set_xlabel('Basis States', fontsize=30, fontweight='bold')
    ax.set_ylabel('Probability Amplitude', fontsize=30, fontweight='bold')
    ax.set_xticks(x_pos)
    ax.set_xticklabels(basis_states, fontsize=30)
    
    # Set y-axis limits based on data range (with some padding)
    y_min = data.min().min()
    y_max = data.max().max()
    if errors is not None:
        y_min = min(y_min, (data - errors).min().min())
        y_max = max(y_max, (data + errors).max().max())
    
    y_padding = (y_max - y_min) * 0.1
    ax.set_ylim(y_min - y_padding, y_max + y_padding)
    
    # Style the plot
    ax.grid(True, alpha=0.3, linestyle='-', linewidth=0.5)
    ax.set_axisbelow(True)
    ax.tick_params(axis='both', which='major', labelsize=30)
    
    # Add time text in top left corner
    time_text = ax.text(0.02, 0.98, f'Time: {time_points[0]}', 
                       transform=ax.transAxes, fontsize=40, fontweight='bold',
                       verticalalignment='top', bbox=dict(boxstyle='round', 
                       facecolor='white', alpha=0.8))
    
    # Initialize error bars if error data is available
    error_bars = None
    if errors is not None:
        error_bars = ax.errorbar(x_pos, data.iloc[:, 0], yerr=errors.iloc[:, 0],
                                fmt='none', color='darkred', linewidth=2, capsize=5)
    
    def animate(frame):
        """Animation function called for each frame"""
        # Get current time point
        current_time = time_points[frame]
        current_values = data.iloc[:, frame]
        
        # Clear the axes and redraw everything (more reliable for animation)
        ax.clear()
        
        # Recreate bars for current frame
        bars = ax.bar(x_pos, current_values, width=bar_width, 
                      color='blue', alpha=0.8, edgecolor='darkgreen', linewidth=1)
        
        # Reapply axes settings
        ax.set_xlabel('Basis States', fontsize=30, fontweight='bold')
        ax.set_ylabel('Probability Amplitude', fontsize=30, fontweight='bold')
        ax.set_xticks(x_pos)
        ax.set_xticklabels(basis_states, fontsize=30)
        ax.set_ylim(y_min - y_padding, y_max + y_padding)
        ax.grid(True, alpha=0.3, linestyle='-', linewidth=0.5)
        ax.set_axisbelow(True)
        ax.tick_params(axis='both', which='major', labelsize=30)
        
        # Add error bars if they exist
        if errors is not None:
            current_errors = errors.iloc[:, frame]
            ax.errorbar(x_pos, current_values, yerr=current_errors,
                       fmt='none', color='darkred', linewidth=2, capsize=5)
        
        # Add time text
        ax.text(0.02, 0.98, f'Time: {current_time}', 
               transform=ax.transAxes, fontsize=30, fontweight='bold',
               verticalalignment='top', bbox=dict(boxstyle='round', 
               facecolor='white', alpha=0.8))
        
        return bars
    
    # Create animation with proper settings
    print("Creating animation...")
    anim = animation.FuncAnimation(fig, animate, frames=len(time_points),
                                 interval=500, blit=False, repeat=True, cache_frame_data=False)
    
    # Save as MP4 with 2 fps using more compatible encoding
    print(f"Saving animation to {output_file}...")
    
    try:
        # Try multiple encoding options for better compatibility
        Writer = animation.writers['ffmpeg']
        
        # Use H.264 codec with compatible settings
        writer = Writer(fps=2, 
                       metadata=dict(artist='Python Matplotlib'), 
                       bitrate=3000,
                       extra_args=['-vcodec', 'libx264', 
                                 '-pix_fmt', 'yuv420p',
                                 '-profile:v', 'baseline',
                                 '-level', '3.0'])
        
        anim.save(output_file, writer=writer, dpi=100)
        print(f"Animation saved successfully to {output_file}")
        
    except Exception as e:
        print(f"Error with H.264 encoding: {e}")
        print("Trying alternative encoding...")
        
        try:
            # Fallback to pillow writer for broader compatibility
            writer = animation.PillowWriter(fps=2)
            gif_file = output_file.replace('.mp4', '.gif')
            anim.save(gif_file, writer=writer, dpi=100)
            print(f"Saved as GIF instead: {gif_file}")
            
        except Exception as e2:
            print(f"Error with GIF fallback: {e2}")
            print("Trying basic MP4 encoding...")
            
            try:
                # Most basic MP4 encoding
                writer = Writer(fps=2, codec='libx264')
                anim.save(output_file, writer=writer, dpi=100)
                print(f"Animation saved with basic encoding to {output_file}")
                
            except Exception as e3:
                print(f"All encoding methods failed: {e3}")
                print("Please check if ffmpeg is properly installed")
                print("You can also try saving as GIF by changing the output filename extension")
    
    plt.tight_layout()
    return fig, anim

# Example usage and data format demonstration
def create_example_data():
    """Create example data files to demonstrate the format"""
    
    # Example data: quantum state amplitudes over time
    # Using ASCII representation for better compatibility
    basis_states = ['|00>', '|01>', '|10>', '|11>']
    time_points = [0.0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0]
    
    # Create some example data (could represent quantum state evolution)
    np.random.seed(42)  # For reproducible example
    data = []
    
    for i, state in enumerate(basis_states):
        # Create some realistic-looking time evolution
        values = []
        for t in time_points:
            # Simulate some oscillatory behavior with decay
            base_val = 0.5 * np.exp(-0.2 * t) * np.cos(2 * np.pi * t + i * np.pi/2)
            noise = 0.05 * np.random.randn()
            values.append(abs(base_val + noise))
        data.append(values)
    
    # Create DataFrame and save as tab-separated file
    df = pd.DataFrame(data, index=basis_states, columns=time_points)
    df.to_csv('example_data.txt', sep='\t')
    
    # Create corresponding error data (typically smaller values)
    error_data = df * 0.1 + 0.02  # 10% relative error plus small absolute error
    error_data.to_csv('example_errors.txt', sep='\t')
    
    print("Example data files created:")
    print("- example_data.txt")
    print("- example_errors.txt")
    print("\nData preview:")
    print(df)
    
    return 'example_data.txt', 'example_errors.txt'

if __name__ == "__main__":
    # Create example data
    #data_file, error_file = create_example_data()

    data_file = "Optimal_vff_delta32.txt"
    error_file = None
    
    # Create animated bar chart with error bars
    fig, anim = create_animated_bar_chart(
        data_file=data_file,
        output_file='quantum_evolution.mp4',
        error_file=error_file
    )
    
    # Show the plot (optional - comment out if running headless)
    plt.show()
    
    print("\nTo use with your own data:")
    print("1. Prepare a tab-separated .txt file with:")
    print("   - First column: basis state labels")
    print("   - First row: time points")
    print("   - Data: values for each basis state at each time")
    print("2. Optionally prepare an error file with the same format")
    print("3. Call: create_animated_bar_chart('your_data.txt', 'output.mp4', 'your_errors.txt')")